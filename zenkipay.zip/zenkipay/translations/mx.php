<?php

global $_MODULE;
$_MODULE = [];
$_MODULE['<{zenkipay}prestashop>zenkipay_c73999545372380f5bd781a8474200b6'] = '¿Estás seguro de querer desinstalar este módulo?';
$_MODULE['<{zenkipay}prestashop>zenkipay_20620e7cb1f3c4e05325d85b0ddb1284'] = '¡Acepte criptos de cualquier billetera, cualquier moneda en su página de pago!';
$_MODULE['<{zenkipay}prestashop>zenkipay_9ac709b178e3d8493d4146198be1a013'] = 'Zenkipay';
$_MODULE['<{zenkipay}prestashop>zenkipay_805b3bec406ea51e904dc2d9aeefd41a'] = 'Detalles de la transacción:';
$_MODULE['<{zenkipay}prestashop>zenkipay_57d5b6ac7b2a08b1d26f60e02fa6da51'] = 'ID transacción';
$_MODULE['<{zenkipay}prestashop>zenkipay_c1f6368d15f7c13c4e5e8f70c68c747f'] = 'Método de pago:';
$_MODULE['<{zenkipay}prestashop>zenkipay_6702a6e3bc2dce95c3e3b61fe578f29c'] = 'Monto:';
$_MODULE['<{zenkipay}prestashop>zenkipay_24a23d787190f2c4812ff9ab11847a72'] = 'Estatus:';
$_MODULE['<{zenkipay}prestashop>zenkipay_e0010a0a1a3259ab5c06a19bad532851'] = 'Pagado';
$_MODULE['<{zenkipay}prestashop>zenkipay_fe3bf6835022f31c5957afd028ca2d53'] = 'Procesado en:';
$_MODULE['<{zenkipay}prestashop>zenkipay_1ee1c44c2dc81681f961235604247b81'] = 'Modo:';
$_MODULE['<{zenkipay}prestashop>zenkipay_955ad3298db330b5ee880c2c9e6f23a0'] = 'Producción';
$_MODULE['<{zenkipay}prestashop>zenkipay_0cbc6611f5540bd0809a388dc95a615b'] = 'Prueba';
$_MODULE['<{zenkipay}prestashop>zenkipay_32d5facdc889dd6e687606994a04bce9'] = 'La extensión PHP cURL debe estar habilitada en tu servidor.';
$_MODULE['<{zenkipay}prestashop>zenkipay_f2253128803cdf73d80abcd51fdc095a'] = 'SSL debe estar habilitado (antes de pasar a modo productivo).';
$_MODULE['<{zenkipay}prestashop>zenkipay_4c78691e149dd7b41a7c7500b70d8282'] = 'Debes crear una cuenta en Zenkipay para obtener tu llave pública.';
$_MODULE['<{zenkipay}prestashop>zenkipay_d97172e0a90fe7afbe3ac0763de33d6b'] = 'Tu servidor debe de contar con PHP 5.6 o posterior.';
$_MODULE['<{zenkipay}prestashop>zenkipay_8b8e0875e7fd2a180a131cd4ff17f7df'] = 'Debe ingresar su clave privada RSA para firmar las transacciones.';
$_MODULE['<{zenkipay}prestashop>zenkipay_a71617338ebb7ba364383dbce557f51c'] = 'La llave de Zenkipay es incorrecta.';
$_MODULE['<{zenkipay}prestashop>zenkipay_3bea592b3ab98132bb281099bc18bf23'] = 'Se ha proporcionado una clave privada RSA no válida.';
$_MODULE['<{zenkipay}prestashop>zenkipay_200c986fde8bd3fc76e751a8b23b9d10'] = 'Todos los chequeos fueron exitosos, ahora puedes comenzar a utilizar Zenkipay.';
$_MODULE['<{zenkipay}prestashop>zenkipay_4e7fb84f9ca0780484cdb5eed31de0b8'] =
    'Al menos un problema fue encontrado para poder comenzar a utilizar Zenkipay. Por favor resuelve los problemas y refresca esta página.';
$_MODULE['<{zenkipay}prestashop>payment_e80f2003247d194f70688ec981ff2d54'] = 'Hubo un problema con su pago.';
$_MODULE['<{zenkipay}prestashop>validation_e2b7dec8fa4b498156dfee6e4c84b156'] = 'Este método de pago no está disponible.';
$_MODULE['<{zenkipay}prestashop>configuration_826cab4ca8503b852c23c6420620a86b'] =
    'Cripto pagos para cualquier ecommerce a nivel mundial. Los compradores pueden pagarte con cualquier billetera y cualquier moneda.';
$_MODULE['<{zenkipay}prestashop>configuration_2fdfd506efea08144c0794c32ca8250a'] = 'Crea una cuenta';
$_MODULE['<{zenkipay}prestashop>configuration_15abc1c28b8ae13a909c44e74b4db480'] = 'Chequeo técnico';
$_MODULE['<{zenkipay}prestashop>configuration_5ef0c737746fae2ca90e66c39333f8f6'] = 'Errores';
$_MODULE['<{zenkipay}prestashop>configuration_254f642527b45bc260048e30704edb39'] = 'Configuración';
$_MODULE['<{zenkipay}prestashop>configuration_650be61892bf690026089544abbd9d26'] = 'Modo';
$_MODULE['<{zenkipay}prestashop>configuration_2652eec977dcb2a5aea85f5bec235b05'] = 'Sandbox';
$_MODULE['<{zenkipay}prestashop>configuration_955ad3298db330b5ee880c2c9e6f23a0'] = 'Producción';
$_MODULE['<{zenkipay}prestashop>configuration_bb29b2bfddc7bfc5600fb7ca413ba1da'] = 'Zenkipay llave Sandbox';
$_MODULE['<{zenkipay}prestashop>configuration_8df186b183eca8447e209abb246baba8'] = 'Zenkipay llave Producción';
$_MODULE['<{zenkipay}prestashop>configuration_f184ec8c23f7201c764d1c9434a206e7'] = 'RSA llave privada';
$_MODULE['<{zenkipay}prestashop>configuration_cf565402d32b79d33f626252949a6941'] = 'Guardar configuración';
$_MODULE['<{zenkipay}prestashop>cc_form_678114c777fb4570c4f2add48ce49481'] = 'Paga con criptos… ¡cualquier billetera, cualquier moneda!. Transacción 100% asegurada.';
$_MODULE['<{zenkipay}prestashop>cc_form_13b83757c15202887090ff6a49dc3cbf'] =
    'Zenkipay es la última y más completa solución de procesamiento de pagos en criptomonedas. Acepte cualquier criptomoneda con más de 150 billeteras en todo el mundo.';
$_MODULE['<{zenkipay}prestashop>cc_form_1da2e8106b3a2171fbb7193a24b91526'] = 'Ha ocurrido un error inesperado.';
