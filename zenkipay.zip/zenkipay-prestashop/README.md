## Zenkipay - PrestaShop plugin

=================

## Installation

1. Log in into your PrestaShop backoffice

2. Go to **Modules > Modules manager** and upload the "zenkipay.zip" file.

3. Enter your Zenkipay's plugin key in the form and you are ready to go.
